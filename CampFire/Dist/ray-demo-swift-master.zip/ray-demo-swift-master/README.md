#RaySDK for iOS Swift demo

Clone with submodule

`git clone --recursive git@github.com:madewithray/ray-demo-swift.git`