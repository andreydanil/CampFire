//
//  RaySDK.h
//  RaySDK
//
//  Created by Sean Ooi on 6/12/15.
//  Copyright (c) 2015 Yella Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for RaySDK.
FOUNDATION_EXPORT double RaySDKVersionNumber;

//! Project version string for RaySDK.
FOUNDATION_EXPORT const unsigned char RaySDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <RaySDK/PublicHeader.h>


