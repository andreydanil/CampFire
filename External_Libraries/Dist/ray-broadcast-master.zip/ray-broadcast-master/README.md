#RaySDK development beacon broadcast

A separate iOS device is required to broadcast in order for the app with the RaySDK integration to receive the signal.

Use the `Test Key` in the **MadeWithRay** dashboard to receive signals from the broadcasting app.