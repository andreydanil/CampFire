#RaySDK for iOS Objective-C demo

Clone with submodule

`git clone --recursive git@github.com:madewithray/ray-demo-objc.git`